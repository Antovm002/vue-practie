<template>
    <div class="container">
        <h1>Esto es un simple componente de informacion</h1>
    </div>
</template>